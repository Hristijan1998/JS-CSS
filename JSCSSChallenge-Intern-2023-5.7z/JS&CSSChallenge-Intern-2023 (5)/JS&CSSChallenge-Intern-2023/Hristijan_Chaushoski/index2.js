const cardData = [
    {
      title: "Card 1",
      description: "This is the first card",
      imageUrl: "https://picsum.photos/300/200",
    },
    {
      title: "Card 2",
      description: "This is the second card",
      imageUrl: "https://picsum.photos/300/200",
    },
    {
      title: "Card 3",
      description: "This is the third card",
      imageUrl: "https://picsum.photos/300/200",
    },
    {
      title: "Card 4",
      description: "This is the fourth card",
      imageUrl: "https://picsum.photos/300/200",
    },
  ];
  
  const cardContainer = document.getElementById("card-container");
  const loadMoreBtn = document.getElementById("load-more-btn");
  
  function renderCard(card) {
    const cardElem = document.createElement("div");
    cardElem.className = "card";
  
    const imgElem = document.createElement("img");
    imgElem.src = card.imageUrl;
  
    const titleElem = document.createElement("h2");
    titleElem.textContent = card.title;
  
    const descElem = document.createElement("p");
    descElem.textContent = card.description;
  
    cardElem.appendChild(imgElem);
    cardElem.appendChild(titleElem);
    cardElem.appendChild(descElem);
  
    return cardElem;
  }
  
  function renderCards(cards) {
    const cardElems = [];
  
    cards.forEach((card) => {
      const cardElem = renderCard(card);
      cardElems.push(cardElem);
    });
  
    return cardElems;
  }
  cardContainer.append(...renderCards(cardData.slice(0, 4)));
  
  function handleLoadMoreClick() {
    const numCardsToAdd = 4;
    const numCardsRendered = cardContainer.children.length;
    const nextCards = cardData.slice(numCardsRendered, numCardsRendered + numCardsToAdd);
  
    cardContainer.append(...renderCards(nextCards));
  
    if (cardContainer.children.length === cardData.length) {
      loadMoreBtn.disabled = true;
    }
  }
  
  loadMoreBtn.addEventListener("click", handleLoadMoreClick);
/*
  function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("demo").innerHTML = this.responseText;
  }
  xhttp.open("GET", "IME NA DATA FAJLOT");
  xhttp.send();
}
function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("demo").innerHTML = this.responseText;
  }
  xhttp.open("GET", "data.json");
  xhttp.send();
}
*/